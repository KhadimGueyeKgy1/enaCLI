from .main import *

def main():
    process()

if __name__ == '__main__':
    main()

